#pragma once
#include "coptcpp.idl.h"

class GenConstr {
public:
  GenConstr(Copt::IGenConstr* ptr) : m_genc(ptr) {}

  int GetIdx() const
  {
    return m_genc->GetIdx();
  }

  int GetIIS() const
  {
    return m_genc->GetIIS();
  }

  void Remove()
  {
    m_genc->Remove();
  }

  Copt::IGenConstr* Get() const
  {
    return &(*m_genc);
  }

private:
  std::shared_ptr<Copt::IGenConstr> m_genc;
};
