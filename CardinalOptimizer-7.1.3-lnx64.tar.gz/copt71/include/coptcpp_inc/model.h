#pragma once
#include <string.h>
#include "coptcpp.idl.h"
#include "var.h"
#include "column.h"
#include "columnarray.h"
#include "expr.h"
#include "quadexpr.h"
#include "exception.h"
#include "constraint.h"
#include "vararray.h"
#include "constrarray.h"
#include "constrbuilderarray.h"
#include "probbuffer.h"
#include "sosarray.h"
#include "sosbuilderarray.h"
#include "genconstrarray.h"
#include "genconstrbuilderarray.h"
#include "conearray.h"
#include "conebuilderarray.h"
#include "psdvar.h"
#include "psdvararray.h"
#include "psdconstraint.h"
#include "psdconstrarray.h"
#include "psdconstrbuilderarray.h"
#include "lmiexpr.h"
#include "lmiconstraint.h"
#include "lmiconstrarray.h"
#include "qconstraint.h"
#include "qconstrarray.h"
#include "qconstrbuilderarray.h"
#include "symmatrix.h"
#include "symmatrixarray.h"
#include "logcallback.h"
#include "callback.h"

class Model {
public:
  Model(Copt::IEnvr* env, const char* szName) : m_model(CreateModel(env, szName))
  {
    CHECKERROR(m_model);
  }
  Model(Copt::IModel* model) : m_model(model) {}

  void Read(const char* szFileName)
  {
    m_model->Read(szFileName);
    CHECKERROR(m_model);
  }

  void ReadMps(const char* szFileName)
  {
    m_model->ReadMps(szFileName);
    CHECKERROR(m_model);
  }

  void ReadLp(const char* szFileName)
  {
    m_model->ReadLp(szFileName);
    CHECKERROR(m_model);
  }

  void ReadSdpa(const char* szFileName)
  {
    m_model->ReadSdpa(szFileName);
    CHECKERROR(m_model);
  }

  void ReadCbf(const char* szFileName)
  {
    m_model->ReadCbf(szFileName);
    CHECKERROR(m_model);
  }

  void ReadBin(const char* szFileName)
  {
    m_model->ReadBin(szFileName);
    CHECKERROR(m_model);
  }

  void ReadSol(const char* szFileName)
  {
    m_model->ReadSol(szFileName);
    CHECKERROR(m_model);
  }

  void ReadBasis(const char* szFileName)
  {
    m_model->ReadBasis(szFileName);
    CHECKERROR(m_model);
  }

  void ReadMst(const char* szFileName)
  {
    m_model->ReadMst(szFileName);
    CHECKERROR(m_model);
  }

  void ReadParam(const char* szFileName)
  {
    m_model->ReadParam(szFileName);
    CHECKERROR(m_model);
  }

  void ReadTune(const char* szFileName)
  {
    m_model->ReadTune(szFileName);
    CHECKERROR(m_model);
  }

  void GetParamInfo(const char* szParam, int* pnCur, int* pnDef, int* pnMin, int* pnMax)
  {
    m_model->GetParamInfo(szParam, pnCur, pnDef, pnMin, pnMax);
    CHECKERROR(m_model);
  }

  void GetParamInfo(const char* szParam, double* pdCur, double* pdDef, double* pdMin, double* pdMax)
  {
    m_model->GetParamInfo(szParam, pdCur, pdDef, pdMin, pdMax);
    CHECKERROR(m_model);
  }

  int GetIntParam(const char* szParam)
  {
    int val = m_model->GetIntParam(szParam);
    CHECKERROR(m_model);
    return val;
  }

  double GetDblParam(const char* szParam)
  {
    double val = m_model->GetDblParam(szParam);
    CHECKERROR(m_model);
    return val;
  }

  void SetIntParam(const char* szParam, int nVal)
  {
    m_model->SetIntParam(szParam, nVal);
    CHECKERROR(m_model);
  }

  void SetDblParam(const char* szParam, double dVal)
  {
    m_model->SetDblParam(szParam, dVal);
    CHECKERROR(m_model);
  }

  void Write(const char* szFileName)
  {
    m_model->Write(szFileName);
    CHECKERROR(m_model);
  }

  void WriteMps(const char* szFileName)
  {
    m_model->WriteMps(szFileName);
    CHECKERROR(m_model);
  }

  ProbBuffer WriteMpsStr()
  {
    ProbBuffer buffer = m_model->WriteMpsStr();
    CHECKERROR(m_model);
    return buffer;
  }

  void WriteLp(const char* szFileName)
  {
    m_model->WriteLp(szFileName);
    CHECKERROR(m_model);
  }

  void WriteCbf(const char* szFileName)
  {
    m_model->WriteCbf(szFileName);
    CHECKERROR(m_model);
  }

  void WriteBin(const char* szFileName)
  {
    m_model->WriteBin(szFileName);
    CHECKERROR(m_model);
  }

  void WriteIIS(const char* szFileName)
  {
    m_model->WriteIIS(szFileName);
    CHECKERROR(m_model);
  }

  void WriteRelax(const char* szFileName)
  {
    m_model->WriteRelax(szFileName);
    CHECKERROR(m_model);
  }

  void WriteSol(const char* szFileName)
  {
    m_model->WriteSol(szFileName);
    CHECKERROR(m_model);
  }

  void WritePoolSol(int iSol, const char* szFileName)
  {
    m_model->WritePoolSol(iSol, szFileName);
    CHECKERROR(m_model);
  }

  void WriteBasis(const char* szFileName)
  {
    m_model->WriteBasis(szFileName);
    CHECKERROR(m_model);
  }

  void WriteMst(const char* szFileName)
  {
    m_model->WriteMst(szFileName);
    CHECKERROR(m_model);
  }

  void WriteParam(const char* szFileName)
  {
    m_model->WriteParam(szFileName);
    CHECKERROR(m_model);
  }

  void WriteTuneParam(int idx, const char* szFileName)
  {
    m_model->WriteTuneParam(idx, szFileName);
    CHECKERROR(m_model);
  }

  int GetIntAttr(const char* szAttr)
  {
    int val = m_model->GetIntAttr(szAttr);
    CHECKERROR(m_model);
    return val;
  }

  double GetDblAttr(const char* szAttr)
  {
    double val = m_model->GetDblAttr(szAttr);
    CHECKERROR(m_model);
    return val;
  }

  Var AddVar(double lb, double ub, double obj, char vtype, const char* szName = nullptr)
  {
    Var var = m_model->AddVar(lb, ub, obj, vtype, szName);
    CHECKERROR(m_model);
    return var;
  }

  Var AddVar(double lb, double ub, double obj, char vtype, const Column& col, const char* szName = nullptr)
  {
    Var var = m_model->AddVar(lb, ub, obj, vtype, col.Get(), szName);
    CHECKERROR(m_model);
    return var;
  }

  VarArray AddVars(int count, char type, const char* szPrefix = "C")
  {
    VarArray vars = m_model->AddVars(count, type, szPrefix);
    CHECKERROR(m_model);
    return vars;
  }

  VarArray AddVars(int count, double lb, double ub, double obj, char vtype, const char* szPrefix = "C")
  {
    VarArray vars = m_model->AddVars(count, lb, ub, obj, vtype, szPrefix);
    CHECKERROR(m_model);
    return vars;
  }

  VarArray AddVars(int count, double* plb, double* pub, double* pobj, char* pvtype, const char* szPrefix = "C")
  {
    VarArray vars = m_model->AddVars(count, plb, pub, pobj, pvtype, szPrefix);
    CHECKERROR(m_model);
    return vars;
  }

  VarArray AddVars(int count,
    double* plb,
    double* pub,
    double* pobj,
    char* pvtype,
    const ColumnArray& cols,
    const char* szPrefix = "C")
  {
    VarArray vars = m_model->AddVars(count, plb, pub, pobj, pvtype, cols.Get(), szPrefix);
    CHECKERROR(m_model);
    return vars;
  }

  Constraint AddConstr(const Expr& expr, char sense, double rhs, const char* szName = nullptr)
  {
    Constraint constr = m_model->AddConstr(expr.Get(), sense, rhs, szName);
    CHECKERROR(m_model);
    return constr;
  }

  Constraint AddConstr(const Expr& lhs, char sense, const Expr& rhs, const char* szName = nullptr)
  {
    Constraint constr = m_model->AddConstr(lhs.Get(), sense, rhs.Get(), szName);
    CHECKERROR(m_model);
    return constr;
  }

  Constraint AddConstr(const Expr& expr, double lb, double ub, const char* szName = nullptr)
  {
    Constraint constr = m_model->AddConstr(expr.Get(), lb, ub, szName);
    CHECKERROR(m_model);
    return constr;
  }

  Constraint AddConstr(const ConstrBuilder& builder, const char* szName = nullptr)
  {
    Constraint constr = m_model->AddConstr(builder.Get(), szName);
    CHECKERROR(m_model);
    return constr;
  }

  ConstrArray AddConstrs(int count, char* pSense, double* pRhs, const char* szPrefix = "R")
  {
    ConstrArray constrs = m_model->AddConstrs(count, pSense, pRhs, szPrefix);
    CHECKERROR(m_model);
    return constrs;
  }

  ConstrArray AddConstrs(int count, double* pLower, double* pUpper, const char* szPrefix = "R")
  {
    ConstrArray constrs = m_model->AddConstrs(count, pLower, pUpper, szPrefix);
    CHECKERROR(m_model);
    return constrs;
  }

  ConstrArray AddConstrs(const ConstrBuilderArray& builders, const char* szPrefix = "R")
  {
    ConstrArray constrs = m_model->AddConstrs(builders.Get(), szPrefix);
    CHECKERROR(m_model);
    return constrs;
  }

  Sos AddSos(const SosBuilder& builder)
  {
    Sos sos = m_model->AddSos(builder.Get());
    CHECKERROR(m_model);
    return sos;
  }

  Sos AddSos(const VarArray& vars, const double* pWeights, int type)
  {
    Sos sos = m_model->AddSos(vars.Get(), pWeights, type);
    CHECKERROR(m_model);
    return sos;
  }

  GenConstr AddGenConstrIndicator(const GenConstrBuilder& builder)
  {
    GenConstr indicator = m_model->AddGenConstrIndicator(builder.Get());
    CHECKERROR(m_model);
    return indicator;
  }

  GenConstr AddGenConstrIndicator(const Var& binVar, int binVal, const ConstrBuilder& constr)
  {
    GenConstr indicator = m_model->AddGenConstrIndicator(binVar.Get(), binVal, constr.Get());
    CHECKERROR(m_model);
    return indicator;
  }

  GenConstr AddGenConstrIndicator(const Var& binVar, int binVal, const Expr& expr, char sense, double rhs)
  {
    GenConstr indicator = m_model->AddGenConstrIndicator(binVar.Get(), binVal, expr.Get(), sense, rhs);
    CHECKERROR(m_model);
    return indicator;
  }

  Cone AddCone(int dim, int type, char* pvtype, const char* szPrefix)
  {
    Cone cone = m_model->AddCone(dim, type, pvtype, szPrefix);
    CHECKERROR(m_model);
    return cone;
  }

  Cone AddCone(const ConeBuilder& builder)
  {
    Cone cone = m_model->AddCone(builder.Get());
    CHECKERROR(m_model);
    return cone;
  }

  Cone AddCone(const VarArray& vars, int type)
  {
    Cone cone = m_model->AddCone(vars.Get(), type);
    CHECKERROR(m_model);
    return cone;
  }

  QConstraint AddQConstr(const QuadExpr& expr, char sense, double rhs, const char* szName = nullptr)
  {
    QConstraint constr = m_model->AddQConstr(expr.Get(), sense, rhs, szName);
    CHECKERROR(m_model);
    return constr;
  }

  QConstraint AddQConstr(const QuadExpr& lhs, char sense, const QuadExpr& rhs, const char* szName = nullptr)
  {
    QConstraint constr = m_model->AddQConstr(lhs.Get(), sense, rhs.Get(), szName);
    CHECKERROR(m_model);
    return constr;
  }

  QConstraint AddQConstr(const QConstrBuilder& builder, const char* szName = nullptr)
  {
    QConstraint constr = m_model->AddQConstr(builder.Get(), szName);
    CHECKERROR(m_model);
    return constr;
  }

  PsdVar AddPsdVar(int dim, const char* szName = nullptr)
  {
    PsdVar var = m_model->AddPsdVar(dim, szName);
    CHECKERROR(m_model);
    return var;
  }

  PsdVarArray AddPsdVars(int count, int* pDim, const char* szPrefix = "PSDV")
  {
    PsdVarArray vars = m_model->AddPsdVars(count, pDim, szPrefix);
    CHECKERROR(m_model);
    return vars;
  }

  PsdConstraint AddPsdConstr(const PsdExpr& expr, char sense, double rhs, const char* szName = nullptr)
  {
    PsdConstraint constr = m_model->AddPsdConstr(expr.Get(), sense, rhs, szName);
    CHECKERROR(m_model);
    return constr;
  }

  PsdConstraint AddPsdConstr(const PsdExpr& expr, double lb, double ub, const char* szName = nullptr)
  {
    PsdConstraint constr = m_model->AddPsdConstr(expr.Get(), lb, ub, szName);
    CHECKERROR(m_model);
    return constr;
  }

  PsdConstraint AddPsdConstr(const PsdExpr& lhs, char sense, const PsdExpr& rhs, const char* szName = nullptr)
  {
    PsdConstraint constr = m_model->AddPsdConstr(lhs.Get(), sense, rhs.Get(), szName);
    CHECKERROR(m_model);
    return constr;
  }

  PsdConstraint AddPsdConstr(const PsdConstrBuilder& builder, const char* szName = nullptr)
  {
    PsdConstraint constr = m_model->AddPsdConstr(builder.Get(), szName);
    CHECKERROR(m_model);
    return constr;
  }

  LmiConstraint AddLmiConstr(const LmiExpr& expr, const char* szName = nullptr)
  {
    LmiConstraint constr = m_model->AddLmiConstr(expr.Get(), szName);
    CHECKERROR(m_model);
    return constr;
  }

  void AddUserCut(const Expr& lhs, char sense, double rhs, const char* szName = nullptr)
  {
    m_model->AddUserCut(lhs.Get(), sense, rhs, szName);
    CHECKERROR(m_model);
  }

  void AddUserCut(const Expr& lhs, char sense, const Expr& rhs, const char* szName = nullptr)
  {
    m_model->AddUserCut(lhs.Get(), sense, rhs.Get(), szName);
    CHECKERROR(m_model);
  }

  void AddUserCut(const ConstrBuilder& builder, const char* szName = nullptr)
  {
    m_model->AddUserCut(builder.Get(), szName);
    CHECKERROR(m_model);
  }

  void AddUserCuts(const ConstrBuilderArray& builders, const char* szPrefix)
  {
    m_model->AddUserCuts(builders.Get(), szPrefix);
    CHECKERROR(m_model);
  }

  void AddLazyConstr(const Expr& lhs, char sense, double rhs, const char* szName = nullptr)
  {
    m_model->AddLazyConstr(lhs.Get(), sense, rhs, szName);
    CHECKERROR(m_model);
  }

  void AddLazyConstr(const Expr& lhs, char sense, const Expr& rhs, const char* szName = nullptr)
  {
    m_model->AddLazyConstr(lhs.Get(), sense, rhs.Get(), szName);
    CHECKERROR(m_model);
  }

  void AddLazyConstr(const ConstrBuilder& builder, const char* szName = nullptr)
  {
    m_model->AddLazyConstr(builder.Get(), szName);
    CHECKERROR(m_model);
  }

  void AddLazyConstrs(const ConstrBuilderArray& builders, const char* szPrefix)
  {
    m_model->AddLazyConstrs(builders.Get(), szPrefix);
    CHECKERROR(m_model);
  }

  SymMatrix AddSparseMat(int dim, int nElems, int* pRows, int* pCols, double* pVals)
  {
    SymMatrix mat = m_model->AddSparseMat(dim, nElems, pRows, pCols, pVals);
    CHECKERROR(m_model);
    return mat;
  }

  SymMatrix AddDenseMat(int dim, double* pVals, int len)
  {
    SymMatrix mat = m_model->AddDenseMat(dim, pVals, len);
    CHECKERROR(m_model);
    return mat;
  }

  SymMatrix AddDenseMat(int dim, double val)
  {
    SymMatrix mat = m_model->AddDenseMat(dim, val);
    CHECKERROR(m_model);
    return mat;
  }

  SymMatrix AddDiagMat(int dim, double* pVals, int len)
  {
    SymMatrix mat = m_model->AddDiagMat(dim, pVals, len);
    CHECKERROR(m_model);
    return mat;
  }

  SymMatrix AddDiagMat(int dim, double val)
  {
    SymMatrix mat = m_model->AddDiagMat(dim, val);
    CHECKERROR(m_model);
    return mat;
  }

  SymMatrix AddDiagMat(int dim, double* pVals, int len, int offset)
  {
    SymMatrix mat = m_model->AddDiagMat(dim, pVals, len, offset);
    CHECKERROR(m_model);
    return mat;
  }

  SymMatrix AddDiagMat(int dim, double val, int offset)
  {
    SymMatrix mat = m_model->AddDiagMat(dim, val, offset);
    CHECKERROR(m_model);
    return mat;
  }

  SymMatrix AddOnesMat(int dim)
  {
    SymMatrix mat = m_model->AddOnesMat(dim);
    CHECKERROR(m_model);
    return mat;
  }

  SymMatrix AddEyeMat(int dim)
  {
    SymMatrix mat = m_model->AddEyeMat(dim);
    CHECKERROR(m_model);
    return mat;
  }

  SymMatrix AddSymMat(const SymMatExpr& expr)
  {
    SymMatrix mat = m_model->AddSymMat(expr.Get());
    CHECKERROR(m_model);
    return mat;
  }

  SymMatrix GetSymMat(int idx)
  {
    SymMatrix mat = m_model->GetSymMat(idx);
    CHECKERROR(m_model);
    return mat;
  }

  void GetSolution(double* pValue)
  {
    m_model->GetSolution(pValue);
    CHECKERROR(m_model);
  }

  void GetLpSolution(double* pValue, double* pSlack, double* pRowDual, double* pRedCost)
  {
    m_model->GetLpSolution(pValue, pSlack, pRowDual, pRedCost);
    CHECKERROR(m_model);
  }

  void SetLpSolution(double* pValue, double* pSlack, double* pRowDual, double* pRedCost)
  {
    m_model->SetLpSolution(pValue, pSlack, pRowDual, pRedCost);
    CHECKERROR(m_model);
  }

  void GetPsdSolution(double* psdColValue, double* psdRowSlack, double* psdRowDual, double* psdColDual)
  {
    m_model->GetPsdSolution(psdColValue, psdRowSlack, psdRowDual, psdColDual);
    CHECKERROR(m_model);
  }

  void GetLmiSolution(double* lmiRowSlack, double* lmiRowDual)
  {
    m_model->GetLmiSolution(lmiRowSlack, lmiRowDual);
    CHECKERROR(m_model);
  }

  int GetColBasis(int* pBasis)
  {
    int status = m_model->GetColBasis(pBasis);
    CHECKERROR(m_model);
    return status;
  }

  int GetRowBasis(int* pBasis)
  {
    int status = m_model->GetRowBasis(pBasis);
    CHECKERROR(m_model);
    return status;
  }

  void SetBasis(int* pColBasis, int* pRowBasis)
  {
    m_model->SetBasis(pColBasis, pRowBasis);
    CHECKERROR(m_model);
  }

  void SetSlackBasis()
  {
    m_model->SetSlackBasis();
    CHECKERROR(m_model);
  }

  double GetPoolObjVal(int iSol)
  {
    double objVal = m_model->GetPoolObjVal(iSol);
    CHECKERROR(m_model);
    return objVal;
  }

  int GetPoolSolution(int iSol, const VarArray& vars, double* pColVals)
  {
    int len = m_model->GetPoolSolution(iSol, vars.Get(), pColVals);
    CHECKERROR(m_model);
    return len;
  }

  int GetVarLowerIIS(const VarArray& vars, int* pLowerIIS)
  {
    int numVar = m_model->GetVarLowerIIS(vars.Get(), pLowerIIS);
    CHECKERROR(m_model);
    return numVar;
  }

  int GetVarUpperIIS(const VarArray& vars, int* pUpperIIS)
  {
    int numVar = m_model->GetVarUpperIIS(vars.Get(), pUpperIIS);
    CHECKERROR(m_model);
    return numVar;
  }

  int GetConstrLowerIIS(const ConstrArray& constrs, int* pLowerIIS)
  {
    int numConstr = m_model->GetConstrLowerIIS(constrs.Get(), pLowerIIS);
    CHECKERROR(m_model);
    return numConstr;
  }

  int GetConstrUpperIIS(const ConstrArray& constrs, int* pUpperIIS)
  {
    int numConstr = m_model->GetConstrUpperIIS(constrs.Get(), pUpperIIS);
    CHECKERROR(m_model);
    return numConstr;
  }

  int GetSOSIIS(const SosArray& soss, int* pIIS)
  {
    int numSos = m_model->GetSOSIIS(soss.Get(), pIIS);
    CHECKERROR(m_model);
    return numSos;
  }

  int GetIndicatorIIS(const GenConstrArray& genconstrs, int* pIIS)
  {
    int numInd = m_model->GetIndicatorIIS(genconstrs.Get(), pIIS);
    CHECKERROR(m_model);
    return numInd;
  }

  double GetCoeff(const Constraint& constr, const Var& var)
  {
    double elem = m_model->GetCoeff(constr.Get(), var.Get());
    CHECKERROR(m_model);
    return elem;
  }

  void SetCoeff(const Constraint& constr, const Var& var, double newVal)
  {
    m_model->SetCoeff(constr.Get(), var.Get(), newVal);
    CHECKERROR(m_model);
  }

  void SetCoeffs(const ConstrArray& constrs, const VarArray& vars, double* vals, int len)
  {
    m_model->SetCoeffs(constrs.Get(), vars.Get(), vals, len);
    CHECKERROR(m_model);
  }

  SymMatrix GetPsdCoeff(const PsdConstraint& constr, const PsdVar& var)
  {
    SymMatrix mat = m_model->GetPsdCoeff(constr.Get(), var.Get());
    CHECKERROR(m_model);
    return mat;
  }

  void SetPsdCoeff(const PsdConstraint& constr, const PsdVar& var, const SymMatrix& mat)
  {
    m_model->SetPsdCoeff(constr.Get(), var.Get(), mat.Get());
    CHECKERROR(m_model);
  }

  SymMatrix GetLmiCoeff(const LmiConstraint& constr, const Var& var)
  {
    SymMatrix mat = m_model->GetLmiCoeff(constr.Get(), var.Get());
    CHECKERROR(m_model);
    return mat;
  }

  void SetLmiCoeff(const LmiConstraint& constr, const Var& var, const SymMatrix& mat)
  {
    m_model->SetLmiCoeff(constr.Get(), var.Get(), mat.Get());
    CHECKERROR(m_model);
  }

  SymMatrix GetLmiRhs(const LmiConstraint& constr)
  {
    SymMatrix mat = m_model->GetLmiRhs(constr.Get());
    CHECKERROR(m_model);
    return mat;
  }

  void SetLmiRhs(const LmiConstraint& constr, const SymMatrix& mat)
  {
    m_model->SetLmiRhs(constr.Get(), mat.Get());
    CHECKERROR(m_model);
  }

  Var GetVar(int idx) const
  {
    Var var = m_model->GetVar(idx);
    CHECKERROR(m_model);
    return var;
  }

  Var GetVarByName(const char* szName)
  {
    Var var = m_model->GetVarByName(szName);
    CHECKERROR(m_model);
    return var;
  }

  VarArray GetVars()
  {
    VarArray vars = m_model->GetVars();
    CHECKERROR(m_model);
    return vars;
  }

  void SetNames(const VarArray& vars, const char* const szNames[], int sz)
  {
    if (!szNames || sz <= 0)
    {
      return;
    }

    size_t len = 1;
    for (int i = 0; i < sz; i++)
    {
      len += strlen(szNames[i]) + 1;
    }

    std::vector<char> buffer(len, 0);

    size_t cnt = 0;
    for (int i = 0; i < sz; i++)
    {
      snprintf(buffer.data() + cnt, len, "%s", szNames[i]);
      cnt += strlen(buffer.data() + cnt) + 1;
    }
    buffer[cnt] = '\0';

    m_model->SetNames(vars.Get(), buffer.data(), len);
    CHECKERROR(m_model);
  }

  Column GetCol(const Var& var)
  {
    Column col = m_model->GetCol(var.Get());
    CHECKERROR(m_model);
    return col;
  }

  Constraint GetConstr(int idx) const
  {
    Constraint constr = m_model->GetConstr(idx);
    CHECKERROR(m_model);
    return constr;
  }

  Constraint GetConstrByName(const char* szName)
  {
    Constraint constr = m_model->GetConstrByName(szName);
    CHECKERROR(m_model);
    return constr;
  }

  ConstrArray GetConstrs()
  {
    ConstrArray constrs = m_model->GetConstrs();
    CHECKERROR(m_model);
    return constrs;
  }

  void SetNames(const ConstrArray& cons, const char* const szNames[], int sz)
  {
    if (!szNames || sz <= 0)
    {
      return;
    }

    size_t len = 1;
    for (int i = 0; i < sz; i++)
    {
      len += strlen(szNames[i]) + 1;
    }

    std::vector<char> buffer(len, 0);

    size_t cnt = 0;
    for (int i = 0; i < sz; i++)
    {
      snprintf(buffer.data() + cnt, len, "%s", szNames[i]);
      cnt += strlen(buffer.data() + cnt) + 1;
    }
    buffer[cnt] = '\0';

    m_model->SetNames(cons.Get(), buffer.data(), len);
    CHECKERROR(m_model);
  }

  ConstrBuilderArray GetConstrBuilders()
  {
    ConstrBuilderArray builders = m_model->GetConstrBuilders();
    CHECKERROR(m_model);
    return builders;
  }

  ConstrBuilder GetConstrBuilder(const Constraint& constr)
  {
    ConstrBuilder builder = m_model->GetConstrBuilder(constr.Get());
    CHECKERROR(m_model);
    return builder;
  }

  Expr GetRow(const Constraint& constr)
  {
    Expr expr = m_model->GetRow(constr.Get());
    CHECKERROR(m_model);
    return expr;
  }

  Sos GetSos(int idx)
  {
    Sos sos = m_model->GetSos(idx);
    CHECKERROR(m_model);
    return sos;
  }

  SosArray GetSoss()
  {
    SosArray soss = m_model->GetSoss();
    CHECKERROR(m_model);
    return soss;
  }

  SosBuilderArray GetSosBuilders()
  {
    SosBuilderArray builders = m_model->GetSosBuilders();
    CHECKERROR(m_model);
    return builders;
  }

  SosBuilderArray GetSosBuilders(SosArray& soss)
  {
    SosBuilderArray builders = m_model->GetSosBuilders(soss.Get());
    CHECKERROR(m_model);
    return builders;
  }

  GenConstrBuilder GetGenConstrIndicator(const GenConstr& indicator)
  {
    GenConstrBuilder ret = m_model->GetGenConstrIndicator(indicator.Get());
    CHECKERROR(m_model);
    return ret;
  }

  Cone GetCone(int idx)
  {
    Cone cone = m_model->GetCone(idx);
    CHECKERROR(m_model);
    return cone;
  }

  ConeArray GetCones()
  {
    ConeArray cones = m_model->GetCones();
    CHECKERROR(m_model);
    return cones;
  }

  ConeBuilderArray GetConeBuilders()
  {
    ConeBuilderArray builders = m_model->GetConeBuilders();
    CHECKERROR(m_model);
    return builders;
  }

  ConeBuilderArray GetConeBuilders(ConeArray& cones)
  {
    ConeBuilderArray builders = m_model->GetConeBuilders(cones.Get());
    CHECKERROR(m_model);
    return builders;
  }

  QConstraint GetQConstr(int idx) const
  {
    QConstraint constr = m_model->GetQConstr(idx);
    CHECKERROR(m_model);
    return constr;
  }

  QConstraint GetQConstrByName(const char* szName)
  {
    QConstraint constr = m_model->GetQConstrByName(szName);
    CHECKERROR(m_model);
    return constr;
  }

  QConstrArray GetQConstrs()
  {
    QConstrArray constrs = m_model->GetQConstrs();
    CHECKERROR(m_model);
    return constrs;
  }

  void SetNames(const QConstrArray& cons, const char* const szNames[], int sz)
  {
    if (!szNames || sz <= 0)
    {
      return;
    }

    size_t len = 1;
    for (int i = 0; i < sz; i++)
    {
      len += strlen(szNames[i]) + 1;
    }

    std::vector<char> buffer(len, 0);

    size_t cnt = 0;
    for (int i = 0; i < sz; i++)
    {
      snprintf(buffer.data() + cnt, len, "%s", szNames[i]);
      cnt += strlen(buffer.data() + cnt) + 1;
    }
    buffer[cnt] = '\0';

    m_model->SetNames(cons.Get(), buffer.data(), len);
    CHECKERROR(m_model);
  }

  QConstrBuilderArray GetQConstrBuilders()
  {
    QConstrBuilderArray builders = m_model->GetQConstrBuilders();
    CHECKERROR(m_model);
    return builders;
  }

  QConstrBuilder GetQConstrBuilder(const QConstraint& constr)
  {
    QConstrBuilder builder = m_model->GetQConstrBuilder(constr.Get());
    CHECKERROR(m_model);
    return builder;
  }

  QuadExpr GetQuadRow(const QConstraint& constr)
  {
    QuadExpr expr = m_model->GetQuadRow(constr.Get());
    CHECKERROR(m_model);
    return expr;
  }

  PsdVar GetPsdVar(int idx) const
  {
    PsdVar var = m_model->GetPsdVar(idx);
    CHECKERROR(m_model);
    return var;
  }

  PsdVar GetPsdVarByName(const char* szName)
  {
    PsdVar var = m_model->GetPsdVarByName(szName);
    CHECKERROR(m_model);
    return var;
  }

  PsdVarArray GetPsdVars()
  {
    PsdVarArray vars = m_model->GetPsdVars();
    CHECKERROR(m_model);
    return vars;
  }

  void SetNames(const PsdVarArray& vars, const char* const szNames[], int sz)
  {
    if (!szNames || sz <= 0)
    {
      return;
    }

    size_t len = 1;
    for (int i = 0; i < sz; i++)
    {
      len += strlen(szNames[i]) + 1;
    }

    std::vector<char> buffer(len, 0);

    size_t cnt = 0;
    for (int i = 0; i < sz; i++)
    {
      snprintf(buffer.data() + cnt, len, "%s", szNames[i]);
      cnt += strlen(buffer.data() + cnt) + 1;
    }
    buffer[cnt] = '\0';

    m_model->SetNames(vars.Get(), buffer.data(), len);
    CHECKERROR(m_model);
  }

  PsdConstraint GetPsdConstr(int idx) const
  {
    PsdConstraint constr = m_model->GetPsdConstr(idx);
    CHECKERROR(m_model);
    return constr;
  }

  PsdConstraint GetPsdConstrByName(const char* szName)
  {
    PsdConstraint constr = m_model->GetPsdConstrByName(szName);
    CHECKERROR(m_model);
    return constr;
  }

  PsdConstrArray GetPsdConstrs()
  {
    PsdConstrArray constrs = m_model->GetPsdConstrs();
    CHECKERROR(m_model);
    return constrs;
  }

  void SetNames(const PsdConstrArray& cons, const char* const szNames[], int sz)
  {
    if (!szNames || sz <= 0)
    {
      return;
    }

    size_t len = 1;
    for (int i = 0; i < sz; i++)
    {
      len += strlen(szNames[i]) + 1;
    }

    std::vector<char> buffer(len, 0);

    size_t cnt = 0;
    for (int i = 0; i < sz; i++)
    {
      snprintf(buffer.data() + cnt, len, "%s", szNames[i]);
      cnt += strlen(buffer.data() + cnt) + 1;
    }
    buffer[cnt] = '\0';

    m_model->SetNames(cons.Get(), buffer.data(), len);
    CHECKERROR(m_model);
  }

  PsdConstrBuilderArray GetPsdConstrBuilders()
  {
    PsdConstrBuilderArray builders = m_model->GetPsdConstrBuilders();
    CHECKERROR(m_model);
    return builders;
  }

  PsdConstrBuilder GetPsdConstrBuilder(const PsdConstraint& constr)
  {
    PsdConstrBuilder builder = m_model->GetPsdConstrBuilder(constr.Get());
    CHECKERROR(m_model);
    return builder;
  }

  PsdExpr GetPsdRow(const PsdConstraint& constr)
  {
    PsdExpr expr = m_model->GetPsdRow(constr.Get());
    CHECKERROR(m_model);
    return expr;
  }

  LmiConstraint GetLmiConstr(int idx) const
  {
    LmiConstraint constr = m_model->GetLmiConstr(idx);
    CHECKERROR(m_model);
    return constr;
  }

  LmiConstraint GetLmiConstrByName(const char* szName)
  {
    LmiConstraint constr = m_model->GetLmiConstrByName(szName);
    CHECKERROR(m_model);
    return constr;
  }

  LmiConstrArray GetLmiConstrs()
  {
    LmiConstrArray constrs = m_model->GetLmiConstrs();
    CHECKERROR(m_model);
    return constrs;
  }

  void SetNames(const LmiConstrArray& cons, const char* const szNames[], int sz)
  {
    if (!szNames || sz <= 0)
    {
      return;
    }

    size_t len = 1;
    for (int i = 0; i < sz; i++)
    {
      len += strlen(szNames[i]) + 1;
    }

    std::vector<char> buffer(len, 0);

    size_t cnt = 0;
    for (int i = 0; i < sz; i++)
    {
      snprintf(buffer.data() + cnt, len, "%s", szNames[i]);
      cnt += strlen(buffer.data() + cnt) + 1;
    }
    buffer[cnt] = '\0';

    m_model->SetNames(cons.Get(), buffer.data(), len);
    CHECKERROR(m_model);
  }

  LmiExpr GetLmiRow(const LmiConstraint& constr)
  {
    LmiExpr expr = m_model->GetLmiRow(constr.Get());
    CHECKERROR(m_model);
    return expr;
  }

  void SetObjSense(int sense)
  {
    m_model->SetObjSense(sense);
    CHECKERROR(m_model);
  }

  void SetObjConst(double constant)
  {
    m_model->SetObjConst(constant);
    CHECKERROR(m_model);
  }

  void SetObjective(const Expr& expr, int sense = 0)
  {
    m_model->SetObjective(expr.Get(), sense);
    CHECKERROR(m_model);
  }

  Expr GetObjective() const
  {
    Expr expr = m_model->GetObjective();
    CHECKERROR(m_model);
    return expr;
  }

  void SetQuadObjective(const QuadExpr& expr, int sense = 0)
  {
    m_model->SetQuadObjective(expr.Get(), sense);
    CHECKERROR(m_model);
  }

  QuadExpr GetQuadObjective()
  {
    QuadExpr expr = m_model->GetQuadObjective();
    CHECKERROR(m_model);
    return expr;
  }

  void DelQuadObj()
  {
    m_model->DelQuadObj();
    CHECKERROR(m_model);
  }

  void SetPsdObjective(const PsdExpr& expr, int sense = 0)
  {
    m_model->SetPsdObjective(expr.Get(), sense);
    CHECKERROR(m_model);
  }

  PsdExpr GetPsdObjective()
  {
    PsdExpr expr = m_model->GetPsdObjective();
    CHECKERROR(m_model);
    return expr;
  }

  void DelPsdObj()
  {
    m_model->DelPsdObj();
    CHECKERROR(m_model);
  }

  void SetMipStart(int count, double* pVals)
  {
    m_model->SetMipStart(count, pVals);
    CHECKERROR(m_model);
  }

  void SetMipStart(const Var& var, double val)
  {
    m_model->SetMipStart(var.Get(), val);
    CHECKERROR(m_model);
  }

  void SetMipStart(const VarArray& vars, double* pVals)
  {
    m_model->SetMipStart(vars.Get(), pVals);
    CHECKERROR(m_model);
  }

  void LoadMipStart()
  {
    m_model->LoadMipStart();
    CHECKERROR(m_model);
  }

  int Get(const char* szName, const VarArray& vars, double* pOut)
  {
    int ret = m_model->Get(szName, vars.Get(), pOut);
    CHECKERROR(m_model);
    return ret;
  }

  int Get(const char* szName, const ConstrArray& constrs, double* pOut)
  {
    int ret = m_model->Get(szName, constrs.Get(), pOut);
    CHECKERROR(m_model);
    return ret;
  }

  int Get(const char* szName, const QConstrArray& constrs, double* pOut)
  {
    int ret = m_model->Get(szName, constrs.Get(), pOut);
    CHECKERROR(m_model);
    return ret;
  }

  int Get(const char* szName, const PsdConstrArray& constrs, double* pOut)
  {
    int ret = m_model->Get(szName, constrs.Get(), pOut);
    CHECKERROR(m_model);
    return ret;
  }

  void Set(const char* szName, const VarArray& vars, double* pVals, int len)
  {
    return m_model->Set(szName, vars.Get(), pVals, len);
    CHECKERROR(m_model);
  }

  void Set(const char* szName, const ConstrArray& constrs, double* pVals, int len)
  {
    return m_model->Set(szName, constrs.Get(), pVals, len);
    CHECKERROR(m_model);
  }

  void Set(const char* szName, const PsdConstrArray& constrs, double* pVals, int len)
  {
    return m_model->Set(szName, constrs.Get(), pVals, len);
    CHECKERROR(m_model);
  }

  void Solve()
  {
    m_model->Solve();
    CHECKERROR(m_model);
  }
  void SolveLp()
  {
    m_model->SolveLp();
    CHECKERROR(m_model);
  }

  void ComputeIIS()
  {
    m_model->ComputeIIS();
    CHECKERROR(m_model);
  }

  void FeasRelax(const VarArray& vars,
    double* pColLowPen,
    double* pColUppPen,
    const ConstrArray& cons,
    double* pRowBndPen,
    double* pRowUppPen)
  {
    m_model->FeasRelax(vars.Get(), pColLowPen, pColUppPen, cons.Get(), pRowBndPen, pRowUppPen);
    CHECKERROR(m_model);
  }
  void FeasRelax(int ifRelaxVars, int ifRelaxCons)
  {
    m_model->FeasRelax(ifRelaxVars, ifRelaxCons);
    CHECKERROR(m_model);
  }

  void Tune()
  {
    m_model->Tune();
    CHECKERROR(m_model);
  }
  void LoadTuneParam(int idx)
  {
    m_model->LoadTuneParam(idx);
    CHECKERROR(m_model);
  }

  void Interrupt()
  {
    m_model->Interrupt();
    CHECKERROR(m_model);
  }

  void Remove(const VarArray& vars)
  {
    m_model->Remove(vars.Get());
  }
  void Remove(const ConstrArray& constrs)
  {
    m_model->Remove(constrs.Get());
  }
  void Remove(const SosArray& soss)
  {
    m_model->Remove(soss.Get());
  }
  void Remove(const ConeArray& cones)
  {
    m_model->Remove(cones.Get());
  }
  void Remove(const GenConstrArray& genConstrs)
  {
    m_model->Remove(genConstrs.Get());
  }
  void Remove(const QConstrArray& constrs)
  {
    m_model->Remove(constrs.Get());
  }
  void Remove(const PsdVarArray& vars)
  {
    m_model->Remove(vars.Get());
  }
  void Remove(const PsdConstrArray& constrs)
  {
    m_model->Remove(constrs.Get());
  }
  void Remove(const LmiConstrArray& constrs)
  {
    m_model->Remove(constrs.Get());
  }

  void ResetParam()
  {
    m_model->ResetParam();
    CHECKERROR(m_model);
  }

  void ResetAll()
  {
    m_model->ResetAll();
    CHECKERROR(m_model);
  }

  void Reset()
  {
    m_model->Reset();
    CHECKERROR(m_model);
  }

  void Clear()
  {
    m_model->Clear();
    CHECKERROR(m_model);
  }

  Model Clone()
  {
    Model model = m_model->Clone();
    CHECKERROR(m_model);
    return model;
  }

  void SetCallback(ICallback* pcb, int cbctx)
  {
    m_model->SetCallback(pcb, cbctx);
    CHECKERROR(m_model);
  }

  void SetSolverLogFile(const char* szLogFile)
  {
    m_model->SetSolverLogFile(szLogFile);
    CHECKERROR(m_model);
  }

  void SetSolverLogCallback(ILogCallback* pcb)
  {
    m_model->SetSolverLogCallback(pcb);
  }

private:
  std::shared_ptr<Copt::IModel> m_model;
};
