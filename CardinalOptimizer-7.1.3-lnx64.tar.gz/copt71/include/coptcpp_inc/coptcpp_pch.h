#ifndef _COPTCPP_PRECOMP_H
#define _COPTCPP_PRECOMP_H

#include <iostream>
#include <vector>
#include <string>

#include "copt.h"
#include "coptcpp.h"
#include "coptcpp.idl.h"

#include "envr.h"
#include "utils.h"

#endif
